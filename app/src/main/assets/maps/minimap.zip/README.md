## minimap

Small balance map
 
